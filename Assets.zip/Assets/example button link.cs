// ExampleScript.cs

using UnityEngine;

public class ExampleScript : MonoBehaviour
{
    void OnEnable()
    {
        // Subscribe to the ModeChanged event in the Button1Script
        Button1Script buttonScript = FindObjectOfType<Button1Script>();
        if (buttonScript != null)
        {
            buttonScript.ModeChanged += OnModeChanged;
        }
    }

    void OnDisable()
    {
        // Unsubscribe from the ModeChanged event
        Button1Script buttonScript = FindObjectOfType<Button1Script>();
        if (buttonScript != null)
        {
            buttonScript.ModeChanged -= OnModeChanged;
        }
    }

    void OnModeChanged(Button1Script.Mode newMode)
    {
        // Perform actions based on the new mode
        if (newMode == Button1Script.Mode.Manual)
        {
            // Code for manual mode
            Debug.Log("Mode changed to Manual");
        }
        else if (newMode == Button1Script.Mode.Auto)
        {
            // Code for auto mode
            Debug.Log("Mode changed to Auto");
        }
    }
}

