using UnityEngine;
using UnityEngine.UI;
using System.IO;
using UnityEngine.EventSystems;
using System;

public class Button1Script : MonoBehaviour, IPointerClickHandler
{
    public Button button;
    public Text modeText;

    public event Action<Mode> ModeChanged;

    public enum Mode
    {
        Manual,
        Auto
    }

    [SerializeField]
    private Mode mode = Mode.Manual;

    private bool clickInProgress = false;
    private float clickTimeThreshold = 0.3f;
    private float clickTimer = 0f;

    void Start()
    {
        button.onClick.AddListener(ButtonClick);
        UpdateModeText();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button == PointerEventData.InputButton.Left)
        {
            if (!clickInProgress)
            {
                clickInProgress = true;
                clickTimer = Time.time;
            }
            else
            {
                if (Time.time - clickTimer <= clickTimeThreshold)
                {
                    clickInProgress = false;
                    ButtonClick();
                }
                else
                {
                    clickTimer = Time.time;
                }
            }
        }
    }

    void ButtonClick()
    {
        Debug.Log("Button clicked!");

        // Toggle the mode between Manual and Auto
        mode = (mode == Mode.Manual) ? Mode.Auto : Mode.Manual;

        // Update the mode text
        UpdateModeText();

        switch (mode)
        {
            case Mode.Manual:
                OpenManualMode();
                break;
            case Mode.Auto:
                OpenAutoMode();
                break;
        }

        // Raise the ModeChanged event
        ModeChanged?.Invoke(mode);
    }

    void OpenManualMode()
    {
        // Add your custom code for manual mode here
        Debug.Log("Manual mode activated!");
    }

    void OpenAutoMode()
    {
        // Add your custom code for auto mode here
        Debug.Log("Auto mode activated!");
    }

    void UpdateModeText()
    {
        if (modeText != null)
        {
            modeText.text = "Mode: " + mode.ToString();
        }
    }
}
