using UnityEngine;
using UnityEngine.UI;
using System.IO;
using UnityEngine.EventSystems;
using System.Collections;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace SimpleFileBrowser
{
    public class SimpleFileBrowser
    {
        public static string[] OpenFilePanel(string title, string directory, string[] extensions, bool multiselect)
        {

            return new string[0];
        }
    }

    public class Button2Script : MonoBehaviour
    {
        public Button button;
        private bool isFileSelectionOpen = false;

        void Start()
        {
            button.onClick.AddListener(ButtonClick);
        }

        void ButtonClick()
        {
            if (isFileSelectionOpen)
            {
                return; 
            }

            Debug.Log("Button clicked!");

#if UNITY_EDITOR
            string filePath = EditorUtility.OpenFilePanel("Select a file", "", "");

            if (!string.IsNullOrEmpty(filePath))
            {
                string fileName = Path.GetFileName(filePath);
                string destinationPath = Path.Combine(Application.dataPath, fileName);

                StartCoroutine(CopyFileAsync(filePath, destinationPath, fileName));
            }
#else
            string[] fileExtensions = { "txt", "png", "jpg" }; // Specify the allowed file extensions

            // Open a file dialog to allow the user to select a file
            StartCoroutine(OpenFilePanelCoroutine(fileExtensions));
#endif
        }

        private IEnumerator OpenFilePanelCoroutine(string[] fileExtensions)
        {
            isFileSelectionOpen = true;

            string[] filePaths = SimpleFileBrowser.OpenFilePanel("Select a file", "", fileExtensions, false);

            isFileSelectionOpen = false;

            if (filePaths != null && filePaths.Length > 0)
            {
                string filePath = filePaths[0];
                string fileName = Path.GetFileName(filePath);
                string destinationPath = Path.Combine(Application.dataPath, fileName);

                // Start the file copy process
                StartCoroutine(CopyFileAsync(filePath, destinationPath, fileName));
            }

            yield return null;
        }

        private IEnumerator CopyFileAsync(string sourcePath, string destinationPath, string fileName)
        {
            yield return new WaitForEndOfFrame(); 

#if UNITY_EDITOR
            try
            {
                File.Copy(sourcePath, destinationPath, true);
                Debug.Log("File uploaded: " + fileName);
            }
            catch (IOException e)
            {
                Debug.LogError("Error uploading file: " + e.Message);
            }
#else
            byte[] fileBytes = File.ReadAllBytes(sourcePath);
            File.WriteAllBytes(destinationPath, fileBytes);

            Debug.Log("File uploaded: " + fileName);
#endif
        }
    }
}
